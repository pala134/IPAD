package com.queue;

public class Ex8_1 {
	public static void main(String args[]) {
		int queueSize = 3;
		char deletedItem;
		ArrayQueue q = new ArrayQueue(queueSize);
		
		q.enQueue('a');
		q.printQueue();
		
		q.enQueue('b');
		q.printQueue();
		
		deletedItem = q.deQueue();
		if(deletedItem != 0){
			System.out.println("deleted Item : "+deletedItem);
		}
		q.printQueue();
		
		q.enQueue('c');
		q.printQueue();
		
		deletedItem = q.deQueue();
		if(deletedItem !=0) {
			System.out.println("deleted Item : "+deletedItem);
		}
		q.printQueue();
		
		deletedItem = q.deQueue();
		if(deletedItem !=0) {
			System.out.println("deleted Item : "+deletedItem);
		}
		q.printQueue();
		
		deletedItem = q.deQueue();
		if(deletedItem !=0) {
			System.out.println("deleted Item : "+deletedItem);
		}
		q.printQueue();
	
	}
}
