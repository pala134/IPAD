package AddrExceptionArrayList;

public class GapException extends RuntimeException {

	public GapException() {

	}
}
