package AddrExceptionArrayList;

public class PhoneDupException extends RuntimeException {
	
	public PhoneDupException() {

	}
}
