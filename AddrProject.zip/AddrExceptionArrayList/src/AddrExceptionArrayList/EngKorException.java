package AddrExceptionArrayList;

public class EngKorException extends RuntimeException {
	
	public EngKorException() {

	}
}
