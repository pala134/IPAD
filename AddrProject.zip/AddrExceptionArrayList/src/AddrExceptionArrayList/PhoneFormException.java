package AddrExceptionArrayList;

public class PhoneFormException extends RuntimeException {
	
	public PhoneFormException() {
		
	}
}
