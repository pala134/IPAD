package bubbleSort1;

public class Main {

	public static void main(String[] args) {
		int[] datas = { 69, 10, 30, 2, 16, 8, 31, 22 };
		Sort sort = new Sort(datas);
		
		sort.printInputData(datas);
		sort.bubbleSort(datas, datas.length);
	}

}
