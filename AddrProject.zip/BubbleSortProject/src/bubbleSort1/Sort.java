package bubbleSort1;

public class Sort {
	int[] datas;
	int num = 1;

	public Sort(int[] datas) {
		this.datas = datas;
	}

	public void swap(int[] datas, int first, int second) {
		int temp;
		temp = datas[first];
		datas[first] = datas[second];
		datas[second] = temp;
	}

	public void bubbleSort(int[] datas, int n) {
		for (int j = 0; j < n - 1; j++) {
			System.out.println("Sorted Data " + (j + 1) + " 단계 : ");
			for (int i = 0; i < n - num; i++) {
				if (datas[i] > datas[i + 1]) {
					swap(datas, i, i + 1);
				}
				print(datas);
			}
			num++;
		}
	}

	public void print(int[] datas) {
		for (int i = 0; i < datas.length; i++) {
			System.out.print(datas[i] + " ");
		}
		System.out.println();
	}

	public void printInputData(int[] datas) {
		System.out.println();
		System.out.print("Input Data : ");
		print(datas);
		System.out.println();
	}
}
