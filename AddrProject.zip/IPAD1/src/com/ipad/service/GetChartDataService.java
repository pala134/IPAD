package com.ipad.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.ipad.dao.SimpleAsDao;
import com.ipad.dto.SimpleAsDto;

public class GetChartDataService implements Service {
	@Override
	   public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
	      String regionCode = request.getParameter("regionCode");
	      System.out.println("getchartDATA rc :" + regionCode);
	      SimpleAsDao simpleAsDao = new SimpleAsDao();
	      ArrayList<SimpleAsDto> simpleAsDto = simpleAsDao.list(regionCode);
	      
	      String jsonResponse = new Gson().toJson(simpleAsDto);
	      System.out.println(jsonResponse);
	      response.setContentType("application/json");
	      response.setCharacterEncoding("UTF-8");
	      
	      try(PrintWriter out = response.getWriter()) {
	         out.print(jsonResponse);
	         out.flush();
	      } catch(IOException e) {
	         e.printStackTrace();
	      }
	   }

}
