package com.ipad.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.ipad.dao.DetailDao;
import com.ipad.dto.DetailDto;

public class GetDetailDataService implements Service {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		String adm_cd = request.getParameter("adm_cd");
		DetailDao dao = new DetailDao();
		ArrayList<DetailDto> dtos = dao.detailDataList(adm_cd);
		
		request.setAttribute("detailList", dtos);
//		Session.setAttribute("detailData", dtos)
//		request.getSession().setAttribute("detailData", dtos);
//		String jsonResponse = new Gson().toJson(dtos);
//		response.setContentType("application/json");
//		   response.setCharacterEncoding("UTF-8");
//
//		   try(PrintWriter out = response.getWriter()) {
//		      out.print(jsonResponse);
//		      out.flush();
//		   } catch(IOException e) {
//		      e.printStackTrace();
//		   }
	}

}
