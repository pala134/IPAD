package com.ipad.service;

import java.util.ArrayList;

import com.ipad.dao.SearchDao;

public class InfoService  {

	
	public void updateData() {
		SearchDao dao = new SearchDao();
		
		ArrayList<String> code = dao.selectAdm();
		
		for (int i = 0; i < code.size(); i++) {
			dao.updateSale(code.get(i));
		}
		
	}

}
