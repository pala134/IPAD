package com.ipad.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HospitalService implements Service {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
	}

}
