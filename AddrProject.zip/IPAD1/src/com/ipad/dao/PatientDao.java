package com.ipad.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class PatientDao {
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet resultSet;
	private DataSource dataSource;
	List<Float> coefficient = new ArrayList<Float>();
	ArrayList<String> admCode = new ArrayList<String>();

	public PatientDao() {
		try {
			Context ctx = new InitialContext();
			Context envContext = (Context) ctx.lookup("java:/comp/env");
			dataSource = (DataSource) envContext.lookup("jdbc/Oracle11g");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<String> getAdmCode() {
		try {
			con = dataSource.getConnection();
			String query = "Select adm_cd from region";
			pstmt = con.prepareStatement(query);
			resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				admCode.add(resultSet.getString("adm_cd"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return admCode;
	}

	public List<Float> getCoef() {
		try {
			con = dataSource.getConnection();
			String query = "select * from patient_point";
			pstmt = con.prepareStatement(query);
			resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				coefficient.add(resultSet.getFloat("constant"));
				coefficient.add(resultSet.getFloat("population_point"));
				coefficient.add(resultSet.getFloat("float_point"));
				coefficient.add(resultSet.getFloat("income_point"));
				coefficient.add(resultSet.getFloat("dentist_point"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return coefficient;
	}
}
