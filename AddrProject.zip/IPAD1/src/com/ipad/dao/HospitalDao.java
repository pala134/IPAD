package com.ipad.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.fasterxml.jackson.databind.JsonNode;

public class HospitalDao {
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet resultSet;
	private DataSource dataSource;
	private ArrayList<String> sigunName = new ArrayList<String>();

	public HospitalDao() {
		try {
			Context ctx = new InitialContext();
			Context envContext = (Context) ctx.lookup("java:/comp/env");
			dataSource = (DataSource) envContext.lookup("jdbc/Oracle11g");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void name() {
		
	}
	
	// Open API를 DB에 저장
	public void saveRecord(JsonNode record) throws SQLException {
		try {
			con = dataSource.getConnection();
			String query = "INSERT INTO Hospital (region, hospital_name, license_date, business_status, address, close_date,x_coordinate, y_coordinate) VALUES (?,?,?,?,?,?,?,?)";

			if (record.get("REFINE_ROADNM_ADDR").asText().contains("위례")) {
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, record.get("SIGUN_NM").asText());
				pstmt.setString(2, record.get("BIZPLC_NM").asText());
				pstmt.setString(3, record.get("LICENSG_DE").asText());
				pstmt.setString(4, record.get("BSN_STATE_NM").asText());
				pstmt.setString(5, record.get("REFINE_ROADNM_ADDR").asText());
				if (record.get("CLSBIZ_DE").asText() != "null") {
					pstmt.setString(6, record.get("CLSBIZ_DE").asText());
				} else {
					pstmt.setString(6, null);
				}
				pstmt.setString(7, record.get("REFINE_WGS84_LAT").asText());
				pstmt.setString(8, record.get("REFINE_WGS84_LOGT").asText());
				pstmt.executeUpdate();
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// DB에서 시군 이름 조회
	public ArrayList<String> getSigunNm() {
		try {
			con = dataSource.getConnection();
			String query = "Select region_name from region where region_name != '송파구'";
			pstmt = con.prepareStatement(query);
			resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				sigunName.add(resultSet.getString("region_name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return sigunName;
	}

	public void deleteEveryData() {
		try {
			con = dataSource.getConnection();
			String query = "DELETE FROM hospital";
			pstmt = con.prepareStatement(query);
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
