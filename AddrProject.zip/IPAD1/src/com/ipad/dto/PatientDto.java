package com.ipad.dto;

public class PatientDto {
	private String adm_cd;
	private String region_name;
	private int predicted_patient;
	private int population_total;
	private int population_float;
	private int income;
	private int dentalClinic;
	
	
}
