package com.Ex7_2;

public class Ex7_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char deletedItem;
		LinkedStack ls = new LinkedStack();

		ls.push('a');
		ls.printStack();

		ls.push('b');
		ls.printStack();

		ls.push('c');
		ls.printStack();

		deletedItem = ls.pop();
		if (deletedItem != 0)
			System.out.println("deleted Item : " + deletedItem);
		ls.printStack();
	}

}
