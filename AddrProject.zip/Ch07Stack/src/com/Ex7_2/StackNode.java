package com.Ex7_2;

public class StackNode {
	char data;
	StackNode link;
}
