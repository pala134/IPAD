package com.Ex7_4;

public class StackNode {
	int data;
	StackNode link;
}
