package addrLinkedList;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList ll = new LinkedList();
		Scanner sc = new Scanner(System.in);
		boolean run = true;

		while (run) {
			menu();

			String num = sc.nextLine();
			switch (num) {
			case "1":
				System.out.println("새로운 연락처를 입력하세요.");
				ll.insertNode(ll.inputNode());
				break;
			case "2":
				ll.printList();
				break;
			case "3":
				System.out.println("검색할 연락처의 이름을 입력하세요.");
				ll.searchNode(sc.nextLine());
				break;
			case "4":
				System.out.println("삭제할 연락처의 이름을 입력하세요.");
				ll.deleteNode(ll.searchNode(sc.nextLine()));
				break;
			case "5":
				run = false;
				break;
			default:
				System.out.println("번호를 다시 입력해 주세요.");
			}
			System.out.println();
		}
		System.out.println("프로그램을 종료합니다.");
		sc.close();
	}
	public static void menu() {
		System.out.println("주소관리메뉴=========");
		System.out.println(">>1. 새 연락처 등록");
		System.out.println(">>2. 모든 연락처 출력");
		System.out.println(">>3. 연락처 검색");
		System.out.println(">>4. 연락처 삭제");
		System.out.println(">>5. 프로그램 종료");
		System.out.println("=================");
	}

}
