package addrLinkedList;

import java.util.Scanner;

public class LinkedList {
	private ListNode head;
	Scanner in;

	public LinkedList() {
		head = null;
		in = new Scanner(System.in);
	}

	public ListNode inputNode() {
		System.out.printf("이름 : ");
		String name = in.nextLine();
		System.out.printf("전화번호 : ");
		String phone = in.nextLine();
		System.out.printf("이메일 : ");
		String email = in.nextLine();
		return new ListNode(name, phone, email);
	}

	public void insertNode(ListNode inputNode) {
		ListNode newNode = inputNode;
		ListNode temp = this.head;
		if (temp == null) {
			head = newNode;
		} else {
			while (temp != null) {
				if (temp.link != null)
					temp = temp.link;
				else {
					temp.link = newNode;
					return;
				}
			}
		}
	}

	public ListNode searchNode(String name) {
		ListNode temp = this.head;
		while (temp != null) {
			if (temp.getName().contentEquals(name)) {
				break;
			} else {
				temp = temp.link;
			}
		}
		temp.printData();
		return temp;
	}

	public void deleteNode(ListNode old) {
		ListNode pre, temp;
		temp = this.head;
		pre = temp.link;
		if(temp ==old) {
			head = old.link;
		}
		else {
			while(temp!=null) {
				if(temp.link == old) {
					temp.link = old.link;
				}else {
					pre = pre.link;
					temp = temp.link;
				}
			}
		}
	}

	public void printList() {
		ListNode temp = this.head;
		System.out.println("L = ");
		while (temp != null) {
			temp.printData();
			temp = temp.link;
			if (temp != null) {
				System.out.println();
			}
		}
		System.out.println();
	}

}
