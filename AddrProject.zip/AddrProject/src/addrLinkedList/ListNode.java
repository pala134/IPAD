package addrLinkedList;

public class ListNode {
	private String name;
	private String phone;
	private String email;
	public ListNode link;

	public ListNode() {
		this.name = null;
		this.phone = null;
		this.email = null;
		this.link = null;
	}
	public ListNode(String name) {
		this.name = name;
		this.link = null;
	}
	public ListNode(String name, String phone, String email) {
		this.name = name;
		this.phone = phone;
		this.email = email;
		this.link = null;
	}
	public ListNode(String name, ListNode link) {
		this.name = name;
		this.link = link;
	}
	public String getName() {
		return this.name;
	}
	public String getPhone() {
		return this.phone;
	}
	public String getEmail() {
		return this.email;
	}
	public void printData() {
		System.out.println("====================");
		System.out.println("이름 : "+name);
		System.out.println("전화번호 : "+phone);
		System.out.println("이메일 : "+email);
		System.out.println("====================");
	}
}
