package addrExceptionArrayList2;

public class CustomerAddr extends Addr {

	private String customer;
	private String item;
	private String rank;

	public CustomerAddr(String name, String number, String email, String address, String birth, String group,
			String customer, String item, String rank) {
		super(name, number, email, address, birth, group);
		this.customer = customer;
		this.item = item;
		this.rank = rank;
	}

	@Override
	public void printinfo() {
		super.printinfo();
		System.out.println("거래처이름 : " + customer);
		System.out.println("품목이름 : " + item);
		System.out.println("직급 : " + rank);
		System.out.println("====================");
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String customerRank) {
		this.rank = customerRank;
	}

}
