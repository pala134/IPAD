package addrExceptionArrayList2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class SmartPhone {
	ArrayList<Addr> addrs;
	Scanner in;

	public SmartPhone() {
		addrs = new ArrayList<>();
		in = new Scanner(System.in);
	}

	public Addr input(int i) {
		System.out.print("이름 : ");
		String name = in.nextLine();
		System.out.print("전화번호 : ");
		String number = in.nextLine();
		System.out.print("이메일 : ");
		String email = in.nextLine();
		System.out.print("주소 : ");
		String address = in.nextLine();
		System.out.print("생일 : ");
		String birth = in.nextLine();
		System.out.print("그룹(회사/거래처) : ");
		String group = in.nextLine();
		if (i == 1) {
			System.out.print("회사이름 : ");
			String company = in.nextLine();
			System.out.print("부서이름 : ");
			String part = in.nextLine();
			System.out.print("직급 : ");
			String rank = in.nextLine();
			return new CompanyAddr(name, number, email, address, birth, group, company, part, rank);
		} else if (i == 2) {
			System.out.print("거래처이름 : ");
			String customer = in.nextLine();
			System.out.print("품목이름 : ");
			String item = in.nextLine();
			System.out.print("직급 : ");
			String rank = in.nextLine();
			return new CustomerAddr(name, number, email, address, birth, group, customer, item, rank);
		} else
			return null;
	}

	public void printAll() {
		Iterator<Addr> itr = addrs.iterator();
		while (itr.hasNext()) {
			Addr addr = itr.next();
			addr.printinfo();
		}
	}

	public void save(Addr addr) {
		addrs.add(addr);
		System.out.println(">>데이터가 저장되었습니다. (" + addrs.size() + ") ");
	}

	public Addr search(String name) {
		Iterator<Addr> itr = addrs.iterator();
		while (itr.hasNext()) {
			Addr addr = itr.next();
			if (addr.getName().contentEquals(name)) {
				addr.printinfo();
				return addr;
			}
		}
		System.out.println("검색결과가 없습니다.");
		return null;
	}

	public void delete(String name) {
		Iterator<Addr> itr = addrs.iterator();
		while (itr.hasNext()) {
			Addr addr = itr.next();
			if (addr.getName().contentEquals(name)) {
				itr.remove();
			}
		}
	}

	public void edit(String name, Addr newaddr) {
		Iterator<Addr> itr = addrs.iterator();
		while (itr.hasNext()) {
			Addr addr = itr.next();
			if (addr.getName().contentEquals(name)) {
				addrs.set(addrs.indexOf(addr), newaddr);
				return;
			}

		}
	}
}
