package addrExceptionArrayList2;

public class CompanyAddr extends Addr {
	private String company;
	private String part;
	private String rank;

	public CompanyAddr(String name, String number, String email, String address, String birth, String group,
			String company, String part, String rank) {
		super(name, number, email, address, birth, group);
		this.company = company;
		this.part = part;
		this.rank = rank;

	}

	@Override
	public void printinfo() {
		super.printinfo();
		System.out.println("회사이름 : " + company);
		System.out.println("파트이름 : " + part);
		System.out.println("직급 : " + rank);
		System.out.println("====================");
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPart() {
		return part;
	}

	public void setPart(String part) {
		this.part = part;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

}
