package addrExceptionArrayList;

public class CompanyAddr extends Addr {
	private String company;
	private String part;
	private String rank;

	public CompanyAddr(String name, String phone, String email, String address, String birth, String group,
			String company, String part, String rank) {
		super(name, phone, email, address, birth, group);
		this.company = company;
		this.part = part;
		this.rank = rank;

	}

	@Override
	public void printinfo() {
		System.out.println("====================");
		System.out.println("이름 : " + getName());
		System.out.println("전화번호 : " + getPhone());
		System.out.println("이메일 : " + getEmail());
		System.out.println("주소 : " + getAddress());
		System.out.println("생일 : " + getBirth());
		System.out.println("그룹(회사/거래처) : " + getGroup());
		System.out.println("회사이름 : " + company);
		System.out.println("파트이름 : " + part);
		System.out.println("직급 : " + rank);
		System.out.println("====================");
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPart() {
		return part;
	}

	public void setPart(String part) {
		this.part = part;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

}
