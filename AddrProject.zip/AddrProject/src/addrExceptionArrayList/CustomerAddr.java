package addrExceptionArrayList;

public class CustomerAddr extends Addr {

	private String customer;
	private String item;
	private String rank;

	public CustomerAddr(String name, String phone, String email, String address, String birth, String group,
			String customer, String item, String rank) {
		super(name, phone, email, address, birth, group);
		this.customer = customer;
		this.item = item;
		this.rank = rank;
	}

	@Override
	public void printinfo() {
		System.out.println("====================");
		System.out.println("이름 : " + getName());
		System.out.println("전화번호 : " + getPhone());
		System.out.println("이메일 : " + getEmail());
		System.out.println("주소 : " + getAddress());
		System.out.println("생일 : " + getBirth());
		System.out.println("그룹(회사/거래처) : " + getGroup());
		System.out.println("거래처이름 : " + customer);
		System.out.println("품목이름 : " + item);
		System.out.println("직급 : " + rank);
		System.out.println("====================");
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String customerRank) {
		this.rank = customerRank;
	}

}
