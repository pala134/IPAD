package addrException;

public class PhoneFormException extends RuntimeException {
	public PhoneFormException() {
		
	}
}
