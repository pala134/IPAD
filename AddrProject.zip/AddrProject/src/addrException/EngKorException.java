package addrException;

public class EngKorException extends RuntimeException {
	public EngKorException() {
		
	}
}
