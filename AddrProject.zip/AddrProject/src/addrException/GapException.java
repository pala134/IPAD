package addrException;

public class GapException extends RuntimeException {

	public GapException() {
		
	}
}
