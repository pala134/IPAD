package addrException;

public class PhoneDupException extends RuntimeException {
	public PhoneDupException() {
		
	}
}
