package addrMap3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class SmartPhone {
	Scanner in;
	Map<String, Addr> map;

	public SmartPhone() {
		in = new Scanner(System.in);
		map = new HashMap<>();
	}
	
	
	public Addr input() {
		try {
			System.out.print("전화번호 : ");
			String phone = in.next();
			if (map.containsKey(phone)) {
				throw new Exception();
			}
//			폰 번호를 입력했을 때 중복이 되면 메뉴로 나가게끔 예외처리를 해봤습니다.
			System.out.print("이름 : ");
			String name = in.next();
			System.out.print("번호 : ");
			String number = in.next();
			System.out.print("이메일 : ");
			String email = in.next();
			System.out.print("주소 : ");
			String address = in.next();
			System.out.print("그룹(가족/친구) : ");
			String group = in.next();
			return new Addr(phone, name, number, email, address, group);

		} catch (Exception e) {
			System.out.println("중복된 전화번호 입니다.");
			return null;
		}
	}

	public void save(Addr addr) {
		if (addr == null) {
		} else {
			map.put(addr.getPhone(), addr);
			System.out.println(">>>데이터가 저장되었습니다. (" + map.size() + ")");
		}
	}

	public void printAll() {
		Set<String> keySet = map.keySet();
		Iterator<String> keyIter = keySet.iterator();
		while (keyIter.hasNext()) {
			String key = keyIter.next();
			Addr addr = map.get(key);
			addr.printinfo();
		}
	}

	public String search(String phone) {
		if (map.containsKey(phone)) {
			Addr addr = map.get(phone);
			addr.printinfo();
			return phone;
		} else {
			System.out.println("검색 결과가 없습니다.");
			return null;
		}
	}

	public void delete(String phone) {
		if (map.containsKey(phone)) {
			String key = phone;
			map.remove(key);
		} else {
			System.out.println("검색 결과가 없습니다.");
		}
	}

	public void edit(String phone, Addr inputaddr) {
		if (map.containsKey(phone)) {
			map.remove(phone);
			save(inputaddr);
		}
	}

}
