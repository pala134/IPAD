package addrMap3;

public class Addr {
	private String phone;
//	전화번호를 키로 쓸 껀데 새로운 클래스는 만들지 않으면서 키값의 해쉬코드와 equals를
//	오버라이드 하려고 Addr에 새로운 필드값으로 phone를 만들었습니다.
	private String name;
	private String number;
	private String email;
	private String address;
	private String group;

	public Addr(String phone, String name, String number, String email, String address, String group) {
		this.phone = phone;
		this.name = name;
		this.number = number;
		this.email = email;
		this.address = address;
		this.group = group;
	}

	public void printinfo() {
		System.out.println("====================");
		System.out.println("전화번호 : " + phone);
		System.out.println("이름 : " + name);
		System.out.println("번호 : " + number);
		System.out.println("이메일 : " + email);
		System.out.println("주소 : " + address);
		System.out.println("그룹(회사/거래처) : " + group);
		System.out.println("====================");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
//	Addr 클래스에서 equals를 재정의 하여 phone 필드값이 같으면 true를 리턴하게 했습니다.
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Addr) {
			Addr addr = (Addr) obj;
			return (phone == addr.getPhone());
		} else {
			return false;
		}
	}
//	키값으로 입력될 폰의 해쉬코드 리턴값이 같게 해봤습니다.
	@Override
	public int hashCode() {
		return phone.hashCode();

	}

}
