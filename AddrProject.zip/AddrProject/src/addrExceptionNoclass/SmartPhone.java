package addrExceptionNoclass;

import java.util.Scanner;
import java.util.regex.Pattern;


public class SmartPhone {
	Addr[] addrs;
	Scanner in;
	int num = 0;

	public SmartPhone() {
		addrs = new Addr[10];
		in = new Scanner(System.in);
	}

	public Addr input(int i) {
		System.out.print("이름 : ");
		String name = in.nextLine();
		System.out.print("전화번호 : ");
		String number = in.nextLine();
		System.out.print("이메일 : ");
		String email = in.nextLine();
		System.out.print("주소 : ");
		String address = in.nextLine();
		System.out.print("생일 : ");
		String birth = in.nextLine();
		System.out.print("그룹(회사/거래처) : ");
		String group = in.nextLine();
		if (i == 1) {
			System.out.print("회사명 : ");
			String company = in.nextLine();
			System.out.print("부서이름 : ");
			String part = in.nextLine();
			System.out.print("직급 : ");
			String rank = in.nextLine();
			return new CompanyAddr(name, number, email, address, birth, group, company, part, rank);
		} else if (i == 2) {
			System.out.print("거래처이름 : ");
			String customer = in.nextLine();
			System.out.print("품목이름 : ");
			String item = in.nextLine();
			System.out.print("직급 : ");
			String rank = in.nextLine();
			return new CustomerAddr(name, number, email, address, birth, group, customer, item, rank);
		}
		return null;
	}

	public void add(Addr addr) {
		if (num > 9) {
			System.out.println("저장 한도를 초과하였습니다.");
			return;
		}
		addrs[num] = addr;
		num++;
		System.out.println(">>>데이터가 저장되었습니다. (" + num + ")");
	}

	public void printAll() {
		for (int i = 0; i < num; i++) {
			addrs[i].printinfo();
		}
		return;
	}

	public Addr search(String name) {
		for (int i = 0; i < num; i++) {
			if (addrs[i].getName().contentEquals(name)) {
				addrs[i].printinfo();
				return addrs[i];
			}
		}
		System.out.println("검색 결과가 없습니다.");
		return null;
	}

	public void delete(String name) {
		for (int i = 0; i < num; i++) {
			Addr addr = addrs[i];
			if (addr.getName().contentEquals(name)) {
				for (int j = i; j < (num - 1); j++) {
					addrs[j] = addrs[j + 1];
				}
				num--;
				return;
			}
		}
		System.out.println("검색 결과가 없습니다.");
	}

	public void edit(String name, Addr oldAddr) {
		for (int i = 0; i < num; i++) {
			if (addrs[i].getName().contentEquals(name)) {
				if (oldAddr instanceof CompanyAddr) {
					Addr newCom = input(1);
					addrs[i] = check(newCom);
				} else if (oldAddr instanceof CustomerAddr) {
					Addr newCus = check(input(2));
					addrs[i] = check(newCus);
				}
				return;
			}
		}
		System.out.println("검색결과가 없습니다.");
	}

	public Addr check(Addr addr) {
		while (true) {
			try {
				gapCheck(addr);
				engKorCheck(addr);
				phoneFormCheck(addr);
				phoneDupCheck(addr);
				break;
			} catch (Exception e) {
				if(e.getMessage()=="gapCheck") {
				System.out.println("공백을 제거 합니다.");
				String name = addr.getName();
				String noGap = name.replace(" ", "");
				addr.setName(noGap);
				}
				else if(e.getMessage()=="engKorCheck") {
				System.out.println("이름에는 공백없이 영문자와 한글만 들어갈 수 있습니다. 다시 입력하세요");
				System.out.print("이름 : ");
				String name = in.nextLine();
				addr.setName(name);
				}
				else if(e.getMessage()=="phoneFormCheck") {
				System.out.println("번호를 \"010-3~4자리-4자리\"형식에 맞게 입력해주세요.");
				System.out.print("전화번호 : ");
				String phone = in.nextLine();
				addr.setPhone(phone);
				}
				else if(e.getMessage()=="phoneDupCheck") {
				System.out.println("전화번호가 중복입니다. 다시 확인시고 입력해주세요.");
				System.out.println("전화번호 : ");
				String phone1 = in.nextLine();
				addr.setPhone(phone1);
				}
			}
		}
		return addr;
	}

	public void gapCheck(Addr addr) throws Exception {
		if (addr.getName().contains(" ")) {
			throw new Exception("gapCheck");
		}
	}

	public void engKorCheck(Addr addr) throws Exception {
		if (Pattern.matches("^[a-zA-z가-힣]*$", addr.getName())) {
		} else {
			throw new Exception("engKorCheck");
		}
	}

	public void phoneFormCheck(Addr addr) throws Exception {
		if (Pattern.matches("^010-([0-9]{3,4})-([0-9]{4})$", addr.getPhone())) {
		} else {
			throw new Exception("phoneFormCheck");
		}
	}

	public void phoneDupCheck(Addr addr) throws Exception {
		for (int i = 0; i < num; i++) {
			if (addrs[i].getPhone().contentEquals(addr.getPhone())) {
				throw new Exception("phoneDupCheck");
			}
		}
	}
}
