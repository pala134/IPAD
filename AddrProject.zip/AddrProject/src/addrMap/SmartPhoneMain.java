package addrMap;

import java.util.Scanner;

public class SmartPhoneMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SmartPhone sp = new SmartPhone();

		System.out.println("########데이터를 2개 입력하세요.");
		for (int i = 0; i < 2; i++) {
			sp.save(sp.inputPhone(), sp.input());
		}

		boolean run = true;
		Scanner sc = new Scanner(System.in);

		while (run) {
			System.out.println("주소관리메뉴===========");
			System.out.println(">>1. 연락처 등록");
			System.out.println(">>2. 모든 연락처 출력");
			System.out.println(">>3. 연락처 검색");
			System.out.println(">>4. 연락처 삭제");
			System.out.println(">>5. 연락처 수정");
			System.out.println(">>6. 프로그램 종료");
			System.out.println("===================");

			String num = sc.next();

			switch (num) {
			case "1":
				sp.save(sp.inputPhone(),sp.input());
				break;
			case "2":
				sp.printAll();
				break;
			case "3":
				System.out.println("검색할 전화번호를 입력하세요.");
				sp.search(sc.next());
				break;
			case "4":
				System.out.println("삭제할 전화번호를 입력하세요.");
				sp.delete(sc.next());
				break;
			case "5":
				System.out.println("수정할 전화번호를 입력하세요.");
				String phone = sp.search(sc.next());
				if (phone != null) {
					sp.edit(phone, sp.input());
				}
				break;
			case "6":
				run = false;
				break;
			default:
				System.out.println("번호를 다시 입력하세요.");
				break;

			}
			System.out.println();
		}
		System.out.println("프로그램을 종료합니다.");
		sc.close();
	}

}
