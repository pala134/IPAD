package addrMap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class SmartPhone {
	Addr[] addrs;
	Scanner in;
	Map<String, Addr> map;

	public SmartPhone() {
		addrs = new Addr[10];
		in = new Scanner(System.in);
		map = new HashMap<>();
	}

	public Addr input() {
		System.out.print("이름 : ");
		String name = in.next();
		System.out.print("번호 : ");
		String number = in.next();
		System.out.print("이메일 : ");
		String email = in.next();
		System.out.print("주소 : ");
		String address = in.next();
		System.out.print("그룹(가족/친구) : ");
		String group = in.next();

		return new Addr(name, number, email, address, group);
	}

	public String inputPhone() {
		System.out.print("전화번호 : ");
		String phone = in.next();
		if(map.containsKey(phone)) {
			System.out.println("이미 저장된 번호입니다.");
			
		}
		return phone;

	}

	public void save(String phone, Addr addr) {
		map.put(phone, addr);
		System.out.println(">>>데이터가 저장되었습니다. (" + map.size() + ")");
	}

	public void print(String phone, Addr addr) {
		System.out.println("====================");
		System.out.println("전화번호 : " + phone);
		System.out.println("이름 : " + addr.getName());
		System.out.println("번호 : " + addr.getNumber());
		System.out.println("이메일 : " + addr.getEmail());
		System.out.println("주소 : " + addr.getAddress());
		System.out.println("그룹(가족/친구) : " + addr.getGroup());
		System.out.println("====================");
	}

	public void printAll() {
		Set<String> keySet = map.keySet();
		Iterator<String> keyIter = keySet.iterator();
		while (keyIter.hasNext()) {
			String key = keyIter.next();
			Addr addr = map.get(key);
			print(key, addr);
		}
	}

	public String search(String phone) {
		Set<String> keySet = map.keySet();
		Iterator<String> keyIter = keySet.iterator();
		while (keyIter.hasNext()) {
			String key = keyIter.next();
			Addr addr = map.get(key);
			if (key.contentEquals(phone)) {
				print(key, addr);
				return phone;
			}
		}
		System.out.println("검색 결과가 없습니다.");
		return null;
	}

	public void delete(String phone) {
		Set<String> keySet = map.keySet();
		Iterator<String> keyIter = keySet.iterator();
		while (keyIter.hasNext()) {
			String key = keyIter.next();
			if (key.contentEquals(phone)) {
				map.remove(key);
			}
			return;
		}
		System.out.println("삭제할 검색 결과가 없습니다.");
	}

	public void edit(String phone, Addr inputaddr) {
		Set<String> keySet = map.keySet();
		Iterator<String> keyIter = keySet.iterator();
		while (keyIter.hasNext()) {
			String key = keyIter.next();
			if(key.contentEquals(phone)) {
				map.replace(key, inputaddr);
			}
		}
	}
}
