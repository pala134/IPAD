package com.javaEdu.command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javaEdu.dto.MemberDto;

public interface MemberService {

	public ArrayList<MemberDto> execute(HttpServletRequest request, HttpServletResponse response);

}
