package iFunctionExam;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IFunction sPhone;
		sPhone= new APhone();
		sPhone.name();
		sPhone.call(true);
		sPhone.connectSpeed();
		sPhone.TvRemote(false);
		System.out.println("----------------");
		sPhone=new BPhone();
		sPhone.name();
		sPhone.call(true);
		sPhone.connectSpeed();
		sPhone.TvRemote(true);
		System.out.println("----------------");
		sPhone=new CPhone();
		sPhone.name();
		sPhone.call(true);
		sPhone.connectSpeed();
		sPhone.TvRemote(false);
		System.out.println("----------------");
	}

}
