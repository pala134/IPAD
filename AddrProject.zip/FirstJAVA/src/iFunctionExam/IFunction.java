package iFunctionExam;

public interface IFunction {
	void name();
	void call(boolean positive);
	void connectSpeed();
	void TvRemote(boolean mount);
	
}
