package iFunctionExam;

public class CPhone implements IFunction {
	private String name="CPhone";
	
	public void name() {
		System.out.println(name);
	}
	@Override
	public void call(boolean positive) {
		// TODO Auto-generated method stub
		if(positive) {
			System.out.println("전화 가능합니다.");
		}
		else {
			System.out.println("전화 불가능합니다.");
		}
	}

	@Override
	public void connectSpeed() {
		// TODO Auto-generated method stub
		System.out.println("가능합니다. 4G입니다.");
	}

	@Override
	public void TvRemote(boolean mount) {
		// TODO Auto-generated method stub
		if(mount)	{
			System.out.println("탑재되어 있습니다.");
		}
		else {
			System.out.println("미탑재되어 있습니다.");
		}
	}
}
