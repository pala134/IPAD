package com.d20.m10;

public class Phone {
//	private Person owner;
//	private String phones[]= {"phones1", "phones2"};
	
}
