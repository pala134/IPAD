package com.d20.m10;

public class Person  {
	private Phone[] phones = new Phone[2];

	public Phone[] getPhones() {
		return phones;
	}

	public void setPhones(Phone[] phones) {
		this.phones = phones;
	}
	
//	private Phone phones1;
//	private Phone phones2;
//	public void use(Phone phones[]) {
//		
//	}
//	phones[0]=new Phone();
}
