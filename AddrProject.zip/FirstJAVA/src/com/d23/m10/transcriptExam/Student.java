package com.d23.m10.transcriptExam;

public class Student {
	private String name;
	private Course courses;
		
	public Student(String name ) {
			this.name=name;
			courses=new Course(name);
	}
	public void addTranscript() {
		
	}
	public Course getCourses() {
		return courses;
		
	}
	public String getName() {
		return name;
	}
	
	
}
