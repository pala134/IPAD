package com.d23.m10.transcriptExam;

public class Transcript {
	private String date;
	private String grade;
	private Student student;
	private Course course;
	
	public Transcript(Student student, Course course) {
		this.student=student;
		this.course=course;
	}
	public Student getStudent() {
		return student;
		
	}
	public Course getCourse() {
		return course;
		
	}
	public void setDate(String date) {
		
	}
	public String getDate() {
		return date;
		
	}
	public void setGrade(String date) {
		
	}
	public String getGrade() {
		return grade;
	}
}
