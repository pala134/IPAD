package com.d23.m10.transcriptExam;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student("홍길동");
		Student s2=new Student("홍길서");
		Student s3=new Student("홍길남");
		
		Course se=new Course("Software Engineering");
		Course dp=new Course("Design Pattern");
		
		Transcript t1=new Transcript(s1, se);
		Transcript t2=new Transcript(s2, dp);
		Transcript t3=new Transcript(s3, dp);
		
		
	}

}
