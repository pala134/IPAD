package com.d23.m10.transcriptExam;

public class Course {
	private String name;

	public Course(String name) {
		this.name=name;
	}
	public void addTranscript(Transcript transcript) {
		
	}
	
	public String getName() {
		return name;
		
	}
}
