package com.d23.m10.aggregation;

public class Computer {
	private MainBoard mainBoard;
	private Cpu cpu;
	private Memory memory;
	private PowerSupply powerSupply;
	
	public Computer(MainBoard mainBoard, Cpu cpu, Memory memory, PowerSupply powerSupply) {
		this.mainBoard=mainBoard;
		this.cpu=cpu;
		this.memory=memory;
		this.powerSupply=powerSupply;
	}
	
	public void TurnOn() {
		
	}
	public void TurnOff() {
		
	}
}
