package com.d23.m10.student;

public class Course {
	private String name;
	private Student[] student;
	
	public Course(String name, int i) {
		this.setName(name);
		setStudent(new Student[i]);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Student[] getStudent() {
		return student;
	}

	public void setStudent(Student[] student) {
		this.student = student;
	}
	public void addStudent(Student student) {
		
	}
	public void removeStudent(Student student) {
		
	}
	
}
