package com.d23.m10;

public class Student {
//	public Course registerCourse;
//	public Course dropCourse;
//	
//	
//	public Student() {
//		registerCourse=new Course();
//		dropCourse=new Course();
//	}
//	
//	public void takeAClass(Course course) {
//		
//	}
	public Course course;
	
	public Student() {
		course=new Course();
	}
	public void registerCourse(Course course) {
		
	}
	public void dropCourse(Course course) {
		
	}
}
