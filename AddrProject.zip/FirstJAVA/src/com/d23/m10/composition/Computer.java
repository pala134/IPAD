package com.d23.m10.composition;

public class Computer {
	private MainBoard mb;
	private Cpu c;
	private Memory m;
	private PowerSupply ps;
	
	public Computer() {
		this.mb=new MainBoard();
		this.c=new Cpu();
		this.m=new Memory();
		this.ps=new PowerSupply();
		
	}
}
