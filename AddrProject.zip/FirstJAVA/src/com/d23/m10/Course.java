package com.d23.m10;

public class Course {
	
}
