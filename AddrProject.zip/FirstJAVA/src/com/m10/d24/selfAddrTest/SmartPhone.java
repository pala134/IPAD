package com.m10.d24.selfAddrTest;

import java.util.Scanner;

public class SmartPhone {
	Addr[] addrs;
	Scanner in;
	int num = 0;

	public SmartPhone() {
		addrs = new Addr[10];
		in = new Scanner(System.in);
	}

	public Addr input() {
		System.out.print("이름 : ");
		String name = in.next();
		System.out.print("전화번호 : ");
		String number = in.next();
		System.out.print("이메일 : ");
		String email = in.next();
		System.out.print("주소 : ");
		String address = in.next();
		System.out.print("그룹(가족/친구) : ");
		String group = in.next();

		return new Addr(name, number, email, address, group);

	}

	public void add(Addr addr) {
		if(num>9) {
			System.out.println("저장 한도를 초과하였습니다.");
			return;
		}
		addrs[num] = addr;
		num++;
		System.out.println(">>>데이터가 저장되었습니다. (" + num + ")");
	}

	public void print(Addr addr) {
		System.out.println("====================");
		System.out.println("이름 : " + addr.getName());
		System.out.println("전화번호 : " + addr.getPhone());
		System.out.println("이메일 : " + addr.getEmail());
		System.out.println("주소 : " + addr.getAddress());
		System.out.println("그룹(가족/친구) : " + addr.getGroup());
		System.out.println("====================");
	}

	public void printAll() {
		for (int i = 0; i < num; i++) {
			print(addrs[i]);
		}
		return;
	}

	public String search(String name) {
		for (int i = 0; i < num; i++) {
			Addr addr = addrs[i];
			if (addr.getName().contentEquals(name)) {
				print(addr);
				return name;
			}
		}
		System.out.println("검색 결과가 없습니다.");
		return null;
	}

	public void delete(String name) {
		for (int i = 0; i < num; i++) {
			Addr addr = addrs[i];
			if (addr.getName().contentEquals(name)) {
				for (int j = i; j < (num - 1); j++) {
					addrs[j] = addrs[j + 1];
				}
				num--;
				return;
			}
		}
		System.out.println("검색 결과가 없습니다.");
	}

	public void edit() {
		System.out.println("수정 할 연락처를 입력해주세요.");
		String name = in.next();
		for (int i = 0; i < num; i++) {

			if (addrs[i].getName().contentEquals(name)) {
				Addr newAddr = input();
				addrs[i] = newAddr;
				return;
			}

		}

		System.out.println("검색결과가 없습니다.");
	}
}
