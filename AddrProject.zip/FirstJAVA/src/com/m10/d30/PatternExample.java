package com.m10.d30;

import java.util.regex.Pattern;

public class PatternExample {

	public static void main(String[] args) {

//		String reg = "(010|02)-\\d{3,4}-\\d{4}";
//		String data = "062-682-4603";
		String reg = "\\w+-\\w{5,}";
		String data = "-qwert";
//		String reg = ""
		boolean result = Pattern.matches(reg, data);
		if (result) {
			System.out.println("정규식과 일치합니다.");
		} else {
			System.out.println("정규식과 일치하지 않습니다.");
		}
	}

}
