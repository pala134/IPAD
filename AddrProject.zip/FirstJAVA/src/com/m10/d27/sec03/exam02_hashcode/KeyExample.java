package com.m10.d27.sec03.exam02_hashcode;

import java.util.HashMap;

public class KeyExample {

	public static void main(String[] args) {
//		Key객체를 식별키로 사용해서 String값을 저장하는 HashMap 객체 생성
		HashMap<Key, String> hashMap=new HashMap<Key, String>();
		Key Key1 = new Key(1);
//		식별키 "new Key(1)"로 "홍길동"을 저장함
		
		hashMap.put(new Key(1), "전우치");
		hashMap.put(Key1, "홍길동");
		hashMap.put(new Key(2), "전우치");
		
//		식별키 "new Key(1)"로 "홍길동"을 읽어옴
//		hashMap.get에서 equals를 call
		String value1 = hashMap.get(new Key(1));
		System.out.println(value1);
		
		String value2 = hashMap.get(new Key(2));
		System.out.println(value2);
		
		String value3 = hashMap.get(new Key(3));
		System.out.println(value3);
		
		System.out.println(hashMap.get(Key1));
		System.out.println(Key1.hashCode());
		System.out.println(new Key(1).hashCode());
		System.out.println(new Key(2).hashCode());
		System.out.println(new Key(3).hashCode());
	}

}
