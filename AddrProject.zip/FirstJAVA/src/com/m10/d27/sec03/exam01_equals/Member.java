package com.m10.d27.sec03.exam01_equals;

public class Member {
	public String id;
	
	public Member(String id) {
		this.id=id;
	}
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Member) {
			Member member=(Member) obj;
			if(id.equals(member.id)) {	//id 필드값이 동일한지 검사
				//여기 equals는 String class equals()임
				return true;
			}
		}
		return false;
	}
//	@Override
//	public int hashCode() {
//		return id.hashCode();
//		
//	}
}
