package com.m10.d23.carowner;

public class Person {
	private Car owns;
	
	public Person(Car car) {
		this.owns=car;
	}
	
}
