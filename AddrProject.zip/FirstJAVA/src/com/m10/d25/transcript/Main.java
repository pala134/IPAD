package com.m10.d25.transcript;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student("홍길동");
		Student s2=new Student("홍길서");
		Student s3=new Student("홍길남");
		
		Course c1=new Course("Software Engineering");
		Course c2=new Course("Design Pattern");
		
		Transcript t1=new Transcript(s1,c1);
//		홍길동은 소프트웨어 공학 수강
		Transcript t2=new Transcript(s1,c2);
//		홍길동은 디자인 패턴 수강
		Transcript t3=new Transcript(s2,c2);
//		홍길서는 디자인 패턴 수강
		Transcript t4=new Transcript(s3,c2);
//		홍길남은 디자인 패턴 수강
		
		t2.setDate("2002");
//		홍길동이 디자인 패턴 수강한 년도는 2022년
		
		t1.setGrade("A+");
//		홍길동의 소프트웨어 공학 학점 A+
		t3.setGrade("C+");
//		홍길서의 디자인 패턴 학점 C+
		t4.setGrade("A+");
//		홍길남의 디자인 패턴  학점 A+
		
		for(Course courses:s1.getCourses()) {
			System.out.println(courses.getName());
		}
//		홍길동이 수강하는 모든 과목 출력
		for(Student students:c2.getStudent()) {
			System.out.println(students.getName());
			}
//		디자인 패턴을 수강하는 모든 학생 출력
		
		System.out.println(t1.toString());
		System.out.println(t3.toString());
		System.out.println(t4.toString());
	}

}
