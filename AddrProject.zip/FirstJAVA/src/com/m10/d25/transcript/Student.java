package com.m10.d25.transcript;

import java.util.ArrayList;
import java.util.Iterator;

public class Student {
	private String name;
	ArrayList<Transcript> myTranscript=new ArrayList<>();
	ArrayList<Course> myCourse=new ArrayList<>();
	
	public Student(String name) {
		this.name=name;
	}
	public void addTranscript(Transcript transcript) {
		myTranscript.add(transcript);
	}
	public ArrayList<Course> getCourses() {
		Iterator<Transcript> itr=myTranscript.iterator();
		while(itr.hasNext()) {
			myCourse.add(itr.next().getCourse());
		}
		return myCourse;
	}
	public String getName() {
		return name;
	}
}
