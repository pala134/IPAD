package com.m10.d25.transcript;

import java.util.ArrayList;
import java.util.Iterator;

public class Course {
	private String name;
	ArrayList<Transcript> courseTranscript = new ArrayList<Transcript>();
	ArrayList<Student> students= new ArrayList<Student>();
	
	public Course(String name) {
		this.name=name;
	}
	public String getName() {
		return name;
		}
	public void addTranscript(Transcript transcript) {
		courseTranscript.add(transcript);
	}
	public ArrayList<Student> getStudent(){
		Iterator<Transcript> itr=courseTranscript.iterator();
		while(itr.hasNext()) {
			students.add(itr.next().getStudent());
		}
		return students;
	}
}
