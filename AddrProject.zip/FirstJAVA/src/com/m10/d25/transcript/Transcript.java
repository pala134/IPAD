package com.m10.d25.transcript;

public class Transcript {
	private Course course;
	private Student student;
	private String date;
	private String grade;
	
	
	public Transcript(Student student, Course course) {
		this.student=student;
		this.course=course;
		student.addTranscript(this);
		course.addTranscript(this);
	}
	
	public Student getStudent() {
		return student;
	}
	public Course getCourse() {
		return course;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public String getGrade() {
		return grade;
	}


	public void setGrade(String grade) {
		this.grade = grade;
	}
	@Override
	public String toString() {
		return student.getName()+" "+course.getName()+" "+grade;
	}
}
