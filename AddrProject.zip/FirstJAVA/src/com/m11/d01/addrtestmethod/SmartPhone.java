package com.m11.d01.addrtestmethod;

import java.util.Scanner;
import java.util.regex.Pattern;

public class SmartPhone {
	Addr[] addrs;
	Scanner in;
	int num = 0;

	public SmartPhone() {
		addrs = new Addr[10];
		in = new Scanner(System.in);
	}

	public Addr input(int i) {
		if (i == 1) {
			System.out.print("이름 : ");
			String name = in.nextLine();
			System.out.print("전화번호 : ");
			String number = in.nextLine();
			System.out.print("이메일 : ");
			String email = in.nextLine();
			System.out.print("주소 : ");
			String address = in.nextLine();
			System.out.print("생일 : ");
			String birth = in.nextLine();
			System.out.print("그룹(회사/거래처) : ");
			String group = in.nextLine();
			System.out.print("회사명 : ");
			String company = in.nextLine();
			System.out.print("부서이름 : ");
			String part = in.nextLine();
			System.out.print("직급 : ");
			String rank = in.nextLine();
			return new CompanyAddr(name, number, email, address, birth, group, company, part, rank);
		} else if (i == 2) {
			System.out.print("이름 : ");
			String name = in.nextLine();
			System.out.print("전화번호 : ");
			String number = in.nextLine();
			System.out.print("이메일 : ");
			String email = in.nextLine();
			System.out.print("주소 : ");
			String address = in.nextLine();
			System.out.print("생일 : ");
			String birth = in.nextLine();
			System.out.print("그룹(회사/거래처) : ");
			String group = in.nextLine();
			System.out.print("거래처이름 : ");
			String customer = in.nextLine();
			System.out.print("품목이름 : ");
			String item = in.nextLine();
			System.out.print("직급 : ");
			String rank = in.nextLine();
			return new CustomerAddr(name, number, email, address, birth, group, customer, item, rank);
		}
		return null;

	}

	public void add(Addr addr) {
		if (num > 9) {
			System.out.println("저장 한도를 초과하였습니다.");
			return;
		}
		addrs[num] = addr;
		num++;
		System.out.println(">>>데이터가 저장되었습니다. (" + num + ")");

	}

//	public void print(Addr addr) {
//		
//		System.out.println("====================");
//		System.out.println("이름 : " + addr.getName());
//		System.out.println("전화번호 : " + addr.getPhone());
//		System.out.println("이메일 : " + addr.getEmail());
//		System.out.println("주소 : " + addr.getAddress());
//		System.out.println("생일 : " + addr.getBirth());
//		System.out.println("그룹(회사/거래처) : " + addr.getGroup());
//		System.out.println("====================");
//	}

	public void printAll() {
		for (int i = 0; i < num; i++) {
			addrs[i].printinfo();

		}
		return;
	}

	public Addr search(String name) {
		for (int i = 0; i < num; i++) {
			if (addrs[i].getName().contentEquals(name)) {
				addrs[i].printinfo();
				return addrs[i];
			}
		}
		System.out.println("검색 결과가 없습니다.");
		return null;
	}

	public void delete(String name) {
		for (int i = 0; i < num; i++) {
			Addr addr = addrs[i];
			if (addr.getName().contentEquals(name)) {
				for (int j = i; j < (num - 1); j++) {
					addrs[j] = addrs[j + 1];
				}
				num--;
				return;
			}
		}
		System.out.println("검색 결과가 없습니다.");
	}

	public void edit(String name, Addr oldAddr) {
		for (int i = 0; i < num; i++) {
			if (addrs[i].getName().contentEquals(name)) {
				if (oldAddr instanceof CompanyAddr) {
					Addr newCom = input(1);
					addrs[i] = check(newCom);
				} else if (oldAddr instanceof CustomerAddr) {
					Addr newCus = check(input(2));
					addrs[i] = check(newCus);
				}
				return;
			}

		}

		System.out.println("검색결과가 없습니다.");
	}

	public Addr check(Addr addr) {
		Addr checkedAddr = phoneDupCheck(phoneFormCheck(engKorCheck(gapCheck(addr))));
		return checkedAddr;
		
			
	}

	public Addr gapCheck (Addr addr) {
		
		System.out.println("공백을 제거 합니다.");
		String name = addr.getName();
		String noGap = name.replace(" ", "");
		addr.setName(noGap);
		return addr;
	}
	

	public Addr engKorCheck(Addr addr) {

		while (true) {
			if (Pattern.matches("^[a-zA-z가-힣]*$", addr.getName())) {
				break;
			} else {
				System.out.println("이름에는 공백없이 영문자와 한글만 들어갈 수 있습니다. 다시 입력하세요");
				System.out.print("이름 : ");
				String name = in.nextLine();
				addr.setName(name);
			}
		}
		return addr;
	}

	public Addr phoneFormCheck(Addr addr) {
		while (true) {
			if (Pattern.matches("^010-([0-9]{3,4})-([0-9]{4})$", addr.getPhone())) {
				break;
			} else {
				System.out.println("번호를 \"010-3자리-4자리\"형식에 맞게 입력해주세요.");
				System.out.print("전화번호 : ");
				String phone = in.nextLine();
				addr.setPhone(phone);
				phoneDupCheck(addr);
			}
		}
		return addr;

	}

	public Addr phoneDupCheck(Addr addr) {
		
		for (int i = 0; i < num; i++) {
			while (true) {
				if (addrs[i].getPhone().contentEquals(addr.getPhone())) {
					System.out.println("전화번호가 중복입니다. 다시 확인하시고 입력해주세요.");
					System.out.print("전화번호 : ");
					String phone = in.nextLine();
					addr.setPhone(phone);
					phoneFormCheck(addr);
					continue;
				} else {
					break;
				}
			}
		}
		return addr;

	}
}
