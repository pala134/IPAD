package com.m11.d01.addrtest;

public class GapException extends RuntimeException {

	public GapException() {
		
	}
}
