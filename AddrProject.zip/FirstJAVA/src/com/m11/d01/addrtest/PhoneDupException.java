package com.m11.d01.addrtest;

public class PhoneDupException extends RuntimeException {
	public PhoneDupException() {
		
	}
}
