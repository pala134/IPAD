package com.m11.d01.addrtest;

import java.util.Scanner;

public class SmartPhoneMain {

	public static void main(String[] args) {
		SmartPhone sp = new SmartPhone();
		Scanner sc = new Scanner(System.in);
		boolean run = true;

		while (run) {
			menu();

			String num = sc.nextLine();
			switch (num) {
			case "1":
				System.out.println("새로운 회사를 입력하세요.");
				sp.add(sp.check(sp.input(1)));
				break;
			case "2":
				System.out.println("새로운 거래처를 입력하세요.");
				sp.add(sp.check(sp.input(2)));
			case "3":
				sp.printAll();
				break;
			case "4":
				System.out.println("검색할 연락처를 입력하세요.");
				sp.search(sc.nextLine());
				break;
			case "5":
				System.out.println("삭제할 연락처를 입력하세요.");
				sp.delete(sc.nextLine());
				break;
			case "6":
				System.out.println("수정할 연락처를 입력하세요.");
				Addr newAddr = sp.search(sc.nextLine());

				if (newAddr != null) {
					sp.edit(newAddr.getName(), newAddr);
				}
				break;
			case "7":
				run = false;
				break;
			default:
				System.out.println("번호를 다시 입력해 주세요.");

			}
			System.out.println();
		}
		System.out.println("프로그램을 종료합니다.");
		sc.close();
	}

	public static void menu() {
		System.out.println("주소관리메뉴==========");
		System.out.println(">>1. 회사연락처 등록");
		System.out.println(">>2. 거래처연락처 등록");
		System.out.println(">>3. 모든 연락처 출력");
		System.out.println(">>4. 연락처 검색");
		System.out.println(">>5. 연락처 삭제");
		System.out.println(">>6. 연락처 수정");
		System.out.println(">>7. 프로그램 종료");
		System.out.println("==================");
	}

}
