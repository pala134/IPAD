package com.m11.d01.addrtest;

public class PhoneFormException extends RuntimeException {
	public PhoneFormException() {
		
	}
}
