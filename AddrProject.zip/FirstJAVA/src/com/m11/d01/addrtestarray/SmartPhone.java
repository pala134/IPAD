package com.m11.d01.addrtestarray;

import java.util.ArrayList;
import java.util.Scanner;

public class SmartPhone {
	ArrayList<Addr> addrs;
	Scanner in;

	public SmartPhone() {
		addrs = new ArrayList<>();
		in = new Scanner(System.in);
	}

	public Addr input(int i) {
		System.out.print("이름 : ");
		String name = in.nextLine();
		System.out.print("전화번호 : ");
		String number = in.nextLine();
		System.out.print("이메일 : ");
		String email = in.nextLine();
		System.out.print("주소 : ");
		String address = in.nextLine();
		System.out.print("생일 : ");
		String birth = in.nextLine();
		System.out.print("그룹(회사/거래처) : ");
		if (i == 1) {
			String group = in.nextLine();
			System.out.print("회사명 : ");
			String company = in.nextLine();
			System.out.print("부서이름 : ");
			String part = in.nextLine();
			System.out.print("직급 : ");
			String rank = in.nextLine();
			return new CompanyAddr(name, number, email, address, birth, group, company, part, rank);
		} else if (i == 2) {
			String group = in.nextLine();
			System.out.print("거래처이름 : ");
			String customer = in.nextLine();
			System.out.print("품목이름 : ");
			String item = in.nextLine();
			System.out.print("직급 : ");
			String rank = in.nextLine();
			return new CustomerAddr(name, number, email, address, birth, group, customer, item, rank);
		}
		return null;

	}

	public void add(Addr addr) {
//		if (addrs.size() > 9) {
//			System.out.println("저장 한도를 초과하였습니다.");
//			return;
//		}
//		어레이리스트지만 10개만 입력할꺼면 위에 if 살리면 됨.
		addrs.add(addr);
		System.out.println(">>>데이터가 저장되었습니다. (" + addrs.size() + ")");
	}

	public void printAll() {
		for (int i = 0; i < addrs.size(); i++) {
		 addrs.get(i).printinfo();
		}
		return;
	}

	public Addr search(String name) {
		for (int i = 0; i < addrs.size(); i++) {
			if (addrs.get(i).getName().contentEquals(name)) {
				addrs.get(i).printinfo();
				return addrs.get(i);
			}
		}
		System.out.println("검색 결과가 없습니다.");
		return null;
	}

	public void delete(String name) {
		for (int i = 0; i < addrs.size(); i++) {
			Addr addr = addrs.get(i);
			if (addr.getName().contentEquals(name)) {
				addrs.remove(i);
				return;
			}
		}
		System.out.println("검색 결과가 없습니다.");
	}

	public void edit(String name, Addr oldAddr) {
		for (int i = 0; i < addrs.size(); i++) {
			if (addrs.get(i).getName().contentEquals(name)) {
				if (oldAddr instanceof CompanyAddr) {
					Addr newCom = this.input(1);
					addrs.set(i, newCom);
				} else if (oldAddr instanceof CustomerAddr) {
					Addr newCus = this.input(2);
					addrs.set(i, newCus);
				}
				
				return;
			}

		}

		System.out.println("검색결과가 없습니다.");
	}

}
