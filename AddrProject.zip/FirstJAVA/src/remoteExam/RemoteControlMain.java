package remoteExam;

public class RemoteControlMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RemoteControl rc;
		rc=new Audio();
		
		rc.setMute(true);
		rc.setMute(false);
		rc.setVolume(13);
		rc.turnOn();
		rc.turnOff();
		RemoteControl.changBattery();
		System.out.println("===============");
		rc=new Television();
		rc.setMute(true);
		rc.setMute(false);
		rc.turnOn();
		rc.setVolume(-2);
		rc.setVolume(7);
		rc.turnOff();
		RemoteControl.changBattery();
		System.out.println("================");
		RemoteControl rrc=new RemoteControl(	) {
			private int volume;
			@Override
			public void turnOn() {
				// TODO Auto-generated method stub
				System.out.println("turn on");
			}

			@Override
			public void turnOff() {
				// TODO Auto-generated method stub
				System.out.println("turn off");
			}

			@Override
			public void setVolume(int volume) {
				// TODO Auto-generated method stub
				if(volume>RemoteControl.MAX_VOLUME) {
					this.volume=RemoteControl.MAX_VOLUME;
				}
				else if(volume<RemoteControl.MIN_VOLUME) {
					this.volume=RemoteControl.MIN_VOLUME;
				}
				else {
					this.volume=volume;
				}
				System.out.println("volume"+this.volume);
					
			}
			
		};
		rrc.turnOn();
		rrc.turnOff();
		rrc.setMute(true);
		rrc.setVolume(7);
		rrc.setVolume(12);
		RemoteControl.changBattery();
	}

}
