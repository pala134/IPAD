package CodingProject2;

public class Memberr {
		String name, num, subject, year, eMail, birth, adress;

	
		Memberr(){
			name = "이다연";
			num = "010-1234-5647";
			subject = "컴퓨터";
			year = "2";
			eMail = "daani@gmail.com";
			birth = "1994-08-22";
			adress = "부천";			
		}
		Memberr(String a){
			this();
			name = a;
		}
	
	}


