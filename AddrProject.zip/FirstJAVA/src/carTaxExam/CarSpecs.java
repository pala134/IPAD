package carTaxExam;

public class CarSpecs {
	public static final String[] color= {"blue","red"};
	public static final String[] tire= {"normal","wide"};
	public static final int[] displacement= {2000,2500};
	public static final String[] handle= {"normal","power"};
	
	
	
}
