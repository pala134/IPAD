package carTaxExam;

public class SonataMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sonata sonataLow=new SonataLowGrade(CarSpecs.color[0],CarSpecs.tire[0],CarSpecs.displacement[0],CarSpecs.handle[0]);
		Sonata sonataHigh=new SonataHighGrade(CarSpecs.color[1],CarSpecs.tire[1],CarSpecs.displacement[1],CarSpecs.handle[1]);
		sonataLow.getSpec();
		sonataHigh.getSpec();
	}

}
