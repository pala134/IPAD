package sec02.exam02_threadname;

public class ThreadD implements Runnable{
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println();
	}
	
}
