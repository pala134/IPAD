package sec02.exam02_threadname;

public class CalcThread extends Thread {
	public CalcThread(String name) {
		setName(name);
	}

	public void run() {
		for (int i = 0; i < 2000000000; i++) {
			for (int j=0; j<2000000000; j++) {
				
			}
		}
		System.out.println(getName());
	}
}
