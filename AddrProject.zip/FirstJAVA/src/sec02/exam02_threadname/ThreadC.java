package sec02.exam02_threadname;

public class ThreadC extends Thread {
	public ThreadC(String name) {
		this.setName(name);
	}
	public void run() {
		for (int i=0;i<2;i++) {
			System.out.println(this.getName()+"가 말한다!!!");
		}
	}
}
