package sec02.exam02_threadname;

public class ThreadNameExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread mainThread = Thread.currentThread();
		System.out.println("프로그램 시작 스레드 이름 : "+mainThread.getName());
		
		ThreadA thrA = new ThreadA();
		System.out.println("작업 스레드 이름 : "+thrA.getName());
		thrA.start();
		
		ThreadB thrB=new ThreadB();
		System.out.println("작업 스레드 이름 : "+thrB.getName());
		thrB.start();
		
		ThreadC thrC=new ThreadC("쓰레드씨");
		System.out.println("작업 스레드 이름 : "+thrC.getName());
		thrC.start();
	}

}
