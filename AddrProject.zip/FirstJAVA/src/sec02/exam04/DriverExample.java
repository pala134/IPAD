package sec02.exam04;

public class DriverExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Driver driver=new Driver();
		Bus bus=new Bus();
		Taxi taxi=new Taxi();
		Vehicle vehicle=new Vehicle();
		
		driver.drive(bus);
		driver.drive(vehicle);
		driver.drive(taxi);
	}

}
