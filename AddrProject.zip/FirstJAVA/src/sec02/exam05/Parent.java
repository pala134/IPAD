package sec02.exam05;

public class Parent {

}
