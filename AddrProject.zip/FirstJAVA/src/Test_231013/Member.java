package Test_231013;

public class Member{
	String name = "자바";
	int age = 22;
	double height = 180;
	
	
	

	}
	


