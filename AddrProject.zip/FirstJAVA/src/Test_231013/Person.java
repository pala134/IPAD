package Test_231013;

public class Person {
	String name;
	String call;
	String ju;
	
	public Person(String name, String call, String ju) {
		this.name = name;
		this.call = call;
		this.ju = ju;
		
	}
}