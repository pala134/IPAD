package Test_231013;

public class PersonExample {

	public static void main(String[] args) {
		Person p1 = new Person("이다연", "123456-1234567", "123-1234-1234");
		
		System.out.println(p1.name);
		System.out.println(p1.call);
		System.out.println(p1.ju);
		
		
	

	}

}
