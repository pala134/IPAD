package Test_231013;

public class Member_2 {

	public static void main(String[] args) {
		Member mem1 = new Member();
		System.out.println("나의 이름은  " + mem1.name + "입니다.");
		Member age1 = new Member();
		Member height1 = new Member();
		System.out.println("나이는 " + age1.age + "입니다. " + "키는 " + height1.height + "cm 입니다.");
		
	}

}
