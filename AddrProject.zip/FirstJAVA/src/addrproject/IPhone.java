package addrproject;

import java.util.Scanner;

public class IPhone {
	Addrs[] addrs;
	Scanner in;
	int num=0;
	
	public IPhone() {
		addrs=new Addrs[10];
		in=new Scanner(System.in);
	}
	public Addrs input() {
		System.out.print("이름 : ");
		String name=in.next();
		System.out.print("전화번호 : ");
		String number=in.next();
		System.out.print("이메일 : ");
		String email=in.next();
		System.out.print("주소 : ");
		String address=in.next();
		System.out.print("그룹(가족/친구) : ");
		String group=in.next();
		
		return new Addrs(name, number, email, address, group);
	}
	public void save(Addrs addr) {
		if(num>9) {
			System.out.println("더 이상 저장 할 수 없습니다.");
		}
		else {
				addrs[num]=addr;
				num++;
		System.out.println(">>>데이터가 저장되었습니다. ("+num+")");
		}
		
	}
	public void print(Addrs addr) {
		System.out.println("이름 : "+addr.getName());
		System.out.println("전화번호 : "+addr.getpNumber());
		System.out.println("이메일 : "+addr.getEmail());
		System.out.println("주소 : "+addr.getAddress());
		System.out.println("그룹(가족/친구) : "+addr.getGroup());
		System.out.println("====================");
	}
	public void printAll() {
		for (int i=0;i<num;i++) {
			print(addrs[i]);
			
		}
	}
	public void search(String name) {
		for(int i=0;i<num;i++) {
			Addrs addr=addrs[i];
			if(addr.getName().contentEquals(name)) {
				print(addr);
				return;
			}
		}
		System.out.println("검색 결과가 없습니다.");
	}
	public void delete(String name) {
		for(int i=0;i<num;i++) {
			Addrs addr=addrs[i];
			if(addr.getName().contentEquals(name)) {
				for(int j=i+1;j<num;j++) {
					addrs[j-1]=addrs[j];
				}
				num--;
				return;
			}
		}
		System.out.println("검색결과가 없습니다.");
	}
	public void edit(String name, Addrs newAddrs) {
		for(int i=0;i<num;i++) {
			if(addrs[i].getName().contentEquals(name)) {
				addrs[i]=newAddrs;
				return;
			}
		}
		System.out.println("검색결과가 없습니다.");
	}
}
