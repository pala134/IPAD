package addrproject;

import java.util.Scanner;

public class SmartPhone {
	
	Addr[] addrs;
	Scanner in; 
	int numOfCount=0;
	
	public SmartPhone() {
		addrs=new Addr[10];
		in=new Scanner(System.in);
	}
//	입력하면 받아지게
	public Addr input() {
		System.out.print("이름 : ");
		String name=in.next();
		System.out.print("전화번호 : ");
		String phoneNumber=in.next();
		System.out.print("이메일 : ");
		String email=in.next();
		System.out.print("주소 : ");
		String address=in.next();
		System.out.print("그룹(가족/친구) : ");
		String group=in.next();
		
		return new Addr(name, phoneNumber, email, address, group);
	}
//	입력값 저장
	public void saveaddr(Addr addr) {
		addrs[numOfCount]=addr;
		numOfCount++;
		System.out.println(">>>데이터가 저장되었습니다.("+numOfCount+")");
		
	}
//	객체 정보를 출력하는 메소드
	public void printAddr(Addr addr) {
		System.out.println("-------------------------");
		System.out.println("이름 : "+addr.getName());
		System.out.println("전화번호 : "+addr.getPhoneNumber());
		System.out.println("이메일 : "+addr.getEmail());
		System.out.println("주소 : "+addr.getAddress());
		System.out.println("그룹(가족/친구) : "+addr.getGroup());
		System.out.println("-------------------------");
		
	}
//	모든 연락처 출력하는 메소드
	public void printAllAddr() {
		for (int i=0;i<numOfCount;i++) {
			printAddr(addrs[i]);
		}
		
	}
//	연락처 검색하는 메소드
//	contentEquals 쓰는법 비교대상.contentEquals(비교대상)
	public void searchAddr(String name) {
		for(int i=0;i<numOfCount;i++) {
			Addr addr=addrs[i];
			if(addr.getName().contentEquals(name)) {
				printAddr(addr);
				return;
			}
			
		}
		System.out.println("검색 결과가 없습니다.");
	}
//	연락처 삭제
	public void deleteAddr(String name) {
		for(int i=0;i<numOfCount;i++)	{
			Addr addr=addrs[i];
			if(addr.getName().contentEquals(name)) {
				for(int j=i;j<numOfCount;j++) {
					addrs[j]=addrs[j+1];
				}
				numOfCount--;
				return;
			}
		}
		System.out.println("검색결과가 없습니다.");
	}
//	연락처 수정
	public void editAddr(String name,Addr newContact) {
		for(int i=0;i<numOfCount;i++) {
			Addr addr=addrs[i];
			if(addr.getName().contentEquals(name)) {
				addrs[i]=newContact;
				return;
			}
		}
		System.out.println("검색결과가 없습니다.");
	}
	
	
}
