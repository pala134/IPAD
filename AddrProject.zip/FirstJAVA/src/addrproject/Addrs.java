package addrproject;

public class Addrs {
	private String name;
	private String pNumber;
	private String email;
	private String address;
	private String group;
	
	public Addrs(String name, String pNumber, String email, String address, String group) {
		this.setName(name);
		this.setpNumber(pNumber);
		this.setEmail(email);
		this.setAddress(address);
		this.setGroup(group);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getpNumber() {
		return pNumber;
	}

	public void setpNumber(String pNumber) {
		this.pNumber = pNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}
	
}
