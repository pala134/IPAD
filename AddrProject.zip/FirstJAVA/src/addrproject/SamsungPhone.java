package addrproject;

import java.util.Scanner;

public class SamsungPhone {
	Addr[] addrs;
	Scanner in;
	int num=0;
	
	public SamsungPhone() {
		addrs=new Addr[10];
		in=new Scanner(System.in);
	}
	public Addr input() {
		System.out.print("이름 : ");
		String name=in.nextLine();
		System.out.print("전화번호 : ");
		String PhoneNumber=in.nextLine();
		System.out.print("이메일 : ");
		String email=in.nextLine();
		System.out.print("주소 : ");
		String address=in.nextLine();
		System.out.print("그룹(가족/친구) : ");
		String group=in.nextLine();
		
		return new Addr(name, PhoneNumber, email, address, group);
	}
	public void save(Addr addr) {
		addrs[num]=addr;
		num++;
		System.out.println(">>>데이터가 저장되었습니다. ("+num+")");
	}
	public void print(Addr addr) {
		System.out.println("====================");
		System.out.println("이름 : "+addr.getName());
		System.out.println("전화번호 : "+addr.getPhoneNumber());
		System.out.println("이메일 : "+addr.getEmail());
		System.out.println("주소 : "+addr.getAddress());
		System.out.println("그룹(가족/친구) : "+addr.getGroup());
		System.out.println("====================");
	}
	public void printAll() {
		for(int i=0;i<num;i++) {
			print(addrs[i]);
		}
	}
	public void search(String name) {
		for(int i=0;i<num;i++) {
			Addr addr=addrs[i];
			if(addr.getName().contentEquals(name)) {
				print(addr);
				return;
			}
		}
		System.out.println("검색 결과가 없습니다.");
	}
	public void delete(String name) {
		for(int i=0;i<num;i++) {
			Addr addr=addrs[i];
			if(addr.getName().contentEquals(name)) {
				for(int j=i;j<num;j++) {
					addrs[j]=addrs[j+1];
				}
				num--;
				return;
			}
		}
		System.out.println("검색 결과가 없습니다.");
	}
	public void edit(String name, Addr newAddr) {
		for(int i=0;i<num;i++) {
			Addr addr=addrs[i];
			if(addr.getName().contentEquals(name)) {
				addr=newAddr;
				return;
			}
		}
		System.out.println("검색 결과가 없습니다.");
	}
}
