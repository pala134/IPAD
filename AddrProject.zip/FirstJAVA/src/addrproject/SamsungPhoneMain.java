package addrproject;

import java.util.Scanner;

public class SamsungPhoneMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SamsungPhone ssp = new SamsungPhone();
				
		System.out.println("###데이터를 2개를 입력합니다.");
		
		for(int i=0;i<2;i++) {
		ssp.save(ssp.input());
		}
		
		boolean run = true;
		Scanner sc=new Scanner(System.in);
		
		while(run) {
			System.out.println("주소관리메뉴==========");
			System.out.println(">>>1. 연락처 등록");
			System.out.println(">>>2. 모든 연락처 출력");
			System.out.println(">>>3. 연락처 검색");
			System.out.println(">>>4. 연락처 삭제");
			System.out.println(">>>5. 연락처 수정");
			System.out.println(">>>6. 프로그램 종료");
			System.out.println("==================");
			
			int num=sc.nextInt();
			sc.nextLine();
//			int num=Integer.parseInt(sc.nextLine());
			switch (num) {
			
			case 1:
				ssp.save(ssp.input());
				break;
			case 2:
				ssp.printAll();
				break;
			case 3:
				System.out.println("검색할 연락처를 입력하세요.");
				ssp.search(sc.nextLine());
				break;
			case 4:
				System.out.println("삭제할 연락처를 입력하세요.");
				ssp.delete(sc.nextLine());
				break;
			case 5:
				System.out.println("수정할 연락처를 검색하세요.");
				String name=sc.nextLine();
				ssp.search(name);
				System.out.println("새로운 연락처를 입력하세요.");
				ssp.edit(name, ssp.input());
				break;
			case 6:
				run=false;
				break;
			default :
				System.out.println("번호를 다시 입력해 주세요.");
				break;
			}
			System.out.println();
		}
		System.out.println("프로그램을 종료합니다.");
		sc.close();
	}

}
