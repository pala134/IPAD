package lunchMenuExam;

public abstract class LunchMenu extends Price {

	public int basic() {
		return bulgogi+rice;
	}
	public abstract int gansik();
	
	public int menu() {
		return basic()+gansik();
	}
	
}
