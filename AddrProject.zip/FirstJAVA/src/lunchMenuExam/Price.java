package lunchMenuExam;

public class Price {
	int rice=1000;
	int bulgogi=5000;
	int banana=700;
	int milk=1000;
	int almond=500;
	
	
	
	
}
