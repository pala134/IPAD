package lunchMenuExam;

public class Student1 extends LunchMenu {
	@Override
	public int gansik() {
		return banana;
	}
}
