package lunchMenuExam;

public class LunchMenuMain {

	public static void main(String[] args) {
		LunchMenu student1=new Student1();
		LunchMenu student2=new Student2();
		
		System.out.println("Student1 식비는"+student1.menu()+"원입니다.");
		System.out.println("Student2 식비는"+student2.menu()+"원입니다.");
		
	}

}
