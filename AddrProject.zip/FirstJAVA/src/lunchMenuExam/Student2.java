package lunchMenuExam;

public class Student2 extends LunchMenu {

	@Override
	public int gansik() {
		return almond+milk;
	}
	
}
