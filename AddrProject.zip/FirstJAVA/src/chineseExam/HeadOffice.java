package chineseExam;

public class HeadOffice {
	String location;
	
	HeadOffice(String location) {
		this.location=location;
	}
	
	void jjajangmyun() {
		System.out.println("짜장면은\t8,000원\t입니다.");
	}
	void jjambbong() {
		System.out.println("짬뽕은\t8,000원\t입니다.");
	}
	void tangsuyuk() {
		System.out.println("탕수육은\t12,000원\t입니다.");
	}
	void goonmandoo() {
		System.out.println("군만두는\t3,000원\t입니다.");
	}
	void gonggibab() {
		System.out.println("공기밥은\t1,000원\t입니다.");
	}
	void menu() {
		System.out.println(location+"\t가격표 입니다.");
		jjajangmyun();
		jjambbong();
		tangsuyuk();
		goonmandoo();
		gonggibab();
		System.out.println("--------------------");
		
	}
}
