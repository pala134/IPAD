package chineseExam;

public class BranchOffice2 extends HeadOffice {

	BranchOffice2(String location) {
		super(location);
	}
	@Override
	void jjajangmyun() {
		System.out.println("짜장면은\t5,000원\t입니다.");
	}
	void jjambbong() {
		System.out.println("짬뽕은\t5,000원\t입니다.");
	}
	void tangsuyuk() {
		System.out.println("탕수육은\t10,000원\t입니다.");
	}
	void gonggibab() {
		System.out.println("공기밥은\t무료\t입니다.");
	}
}
