package chineseExam;

public class BranchOffice1 extends HeadOffice {

	BranchOffice1(String location) {
		super(location);
	}
	@Override
	void jjajangmyun() {
		System.out.println("짜장면은\t7,000원\t입니다.");
	}
	void goonmandoo() {
		System.out.println("군만두는\t판매하지 않습니다.");
	}
	

}
