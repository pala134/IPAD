package chineseExam;

public class BranchOffice3 extends HeadOffice {

	BranchOffice3(String location) {
		super(location);
	}
	@Override
	void jjajangmyun() {
		System.out.println("짜장면은\t7,000원\t입니다.");
	}
	void jjambbong() {
		System.out.println("짬뽕은\t7,000원\t입니다.");
	}

}
