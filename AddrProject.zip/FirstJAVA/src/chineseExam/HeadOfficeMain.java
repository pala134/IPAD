package chineseExam;

public class HeadOfficeMain {

	public static void main(String[] args) {
		HeadOffice headOffice=new HeadOffice("본점");
		BranchOffice1 branch1=new BranchOffice1("1호점");
		BranchOffice2 branch2=new BranchOffice2("2호점");
		BranchOffice3 branch3=new BranchOffice3("3호점");
		headOffice.menu();
		branch1.menu();
		branch2.menu();
		branch3.menu();
	}

}
