package sec04.exam01_unsynchronized;

public class User1 extends Thread {
	private Calculator cal;
	
	public void setCalculator(Calculator cal) {
		this.setName("User 1");
		this.cal=cal;
	}
	@Override
	public void run() {
		cal.setMemory(100);
	}
}
