package CodingProject;

public class Member {
	String name, num, subject, year, eMail, birth, adress;
	
	public Member(String name, String num, String subject, String year, String eMail, String birth, String adress) {
		this.name = name;
		this.num = num;
		this.subject = subject;
		this.year = year;
		this.eMail = eMail;
		this.birth = birth;
		this.adress = adress;
	}
	
	public Member(String name, String num, String subject, String year, String eMail) {
		this.name = name;
		this.num = num;
		this.subject = subject;
		this.year = year;
		this.eMail = eMail;
		this.birth= "정보없음";
		this.adress = "정보없음";
		
	}
}
