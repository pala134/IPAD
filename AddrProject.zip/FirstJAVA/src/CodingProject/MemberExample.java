package CodingProject;

public class MemberExample {
	

	public static void main(String[] args) {
		Member m1 = new Member ("이다연", "010-1234-5678", "컴퓨터", "2", "daani@gmail.com", "1994-08-22", "부천");
		Member m2 = new Member ("윤석진", "010-1234-5678", "컴퓨터", "4", "man0805@gmail.com");
		
		System.out.println("이름  : " + m1.name);
		System.out.println("전화번호 : " + m1.num);
		System.out.println("전공 : " + m1.subject);
		System.out.println("학년  : " + m1.year);
		System.out.println("이메일  : " + m1.eMail);
		System.out.println("생일 : " + m1.birth);
		System.out.println("주소 : " + m1.adress);
		System.out.println("-----------------------");
		
		
		System.out.println("이름  : " + m2.name);
		System.out.println("전화번호 : " + m2.num);
		System.out.println("전공 : " + m2.subject);
		System.out.println("학년  : " + m2.year);
		System.out.println("이메일  : " + m2.eMail);
		System.out.println("생일 : " + m2.birth );
		System.out.println("주소 : " + m2.adress );
		System.out.println("완성했따!!!!!!!!!!!!!!!!!!!!!!!!1");
	}
		

}
