package Test_231012;

public class StudentExample {

	public static void main(String[] args) {
		Student s1 = new Student();
		System.out.print("s1 변수가 Student 객체를 참조합니다.");
		

	}
	
}
	class Student{ 
		
	}