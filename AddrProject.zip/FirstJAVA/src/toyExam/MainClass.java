package toyExam;

public class MainClass {

	public static void main(String[] args) {
		Toy bear=new BearToy();
		Toy mazinger=new MazingerToy();
		Toy airPlane=new AirPlaneToy();
		
		Toy[] toy= {bear, mazinger, airPlane};
		for(Toy toys:toy) {
			toys.print();
			System.out.println("-------------");
		}
			
		
	}

}
