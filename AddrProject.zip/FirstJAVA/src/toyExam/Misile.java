package toyExam;

public interface Misile extends Toy {
	void launch();
}
