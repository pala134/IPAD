package toyExam;

public interface Toy {
	void name();
	void print();
}
