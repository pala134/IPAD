package toyExam;

public class AirPlaneToy implements Misile, Light {

	@Override
	public void name() {
		System.out.println("비행기입니다.");
	}

	@Override
	public void light() {
		System.out.println("불빛 발사가 가능합니다.");
	}

	@Override
	public void launch() {
		System.out.println("미사일 발사가 가능합니다.");
	}

	
	@Override
	public void print() {
		// TODO Auto-generated method stub
		name();
		light();
		launch();
	}
	
}
