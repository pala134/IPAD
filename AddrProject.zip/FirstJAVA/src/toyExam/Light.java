package toyExam;

public interface Light extends Toy {
	void light();
}
