package toyExam;

public interface MoveArmLeg extends Toy{
	void move();
}
