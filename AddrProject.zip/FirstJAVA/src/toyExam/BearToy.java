package toyExam;

public class BearToy implements MoveArmLeg {

	@Override
	public void name() {
		System.out.println("곰돌이 입니다.");
	}

	@Override
	public void move() {
		System.out.println("팔다리를 움직일 수 있습니다.");
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		name();
		move();
	}

}
