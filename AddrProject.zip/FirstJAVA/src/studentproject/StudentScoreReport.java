package studentproject;

public class StudentScoreReport {

	public static void main(String[] args) {
		Student[] student=new Student[10];
		student[0] = new Student("김경민", 100, 70, 80);
		student[1] = new Student("김준호", 70, 80, 60);
		student[2] = new Student("백승재", 80, 70, 70);
		student[3] = new Student("서민수", 60, 80, 80);
		student[4] = new Student("송도훈", 50, 60, 70);
		student[5] = new Student("신지용", 70, 50, 60);
		student[6] = new Student("이영준", 90, 90, 50);
		student[7] = new Student("장홍기", 90, 80, 60);
		student[8] = new Student("조진석", 80, 70, 90);
		student[9] = new Student("한현섭", 100, 80, 90);
		
		System.out.println("###Score Report###");
		System.out.println("이름\t국어\t영어\t수학\t|\t총합\t평균");
		System.out.println("-------------------------------------------------------------------------------------");
//		for(int i=0;i<students.length;i++)
		for(Student std:student)
//			System.out.printf(students[i].getName()+"\t"+students[i].getKorScore()+"\t"+students[i].getEngScore()+"\t"+students[i].getMathScore()+"\t|\t"+students[i].sumScore()+"\t"+("%.1f\n"),students[i].avgScore());
			System.out.printf(std.getName()+"\t"+std.getKorScore()+"\t"+std.getEngScore()+"\t"+std.getMathScore()+"\t|\t"+std.sumScore()+"\t"+("%.1f\n"),std.avgScore());
		
	}

}
