package interfaceExam;

public interface interfaceEx2 {
	String CONSTANT_STRING="HELLO WORLD";
	
	public String getStr();
}
