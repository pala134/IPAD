package interfaceExam;

public interface interfaceEx {
	public static int CONSTANT_NUM=1000;
	
	public void calculate();
}
