package interfaceExam;

public class InterfaceClass implements interfaceEx, interfaceEx2 {


@Override
public void calculate() {
	// TODO Auto-generated method stub
	System.out.println("calculate 실제구현은 여기서 해요.");
	
	
}

@Override
public String getStr() {
	// TODO Auto-generated method stub
	System.out.println("getStr 실제구현은 여기서 해요.");
	return null;
}
}
