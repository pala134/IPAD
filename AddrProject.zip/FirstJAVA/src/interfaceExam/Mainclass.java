package interfaceExam;

public class Mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceClass interfaceclass = new InterfaceClass();
		interfaceclass.getStr();
		interfaceclass.calculate();
		
		interfaceEx ife=new InterfaceClass();
		ife.calculate();
//		ife.getStr();
		interfaceEx2 ife2=new InterfaceClass();
		ife2.getStr();
	}

}
