package sec06.exam05_wait_notify;

public class DataBox {

}
