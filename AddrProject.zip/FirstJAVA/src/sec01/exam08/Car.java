package sec01.exam08;

public class Car {

}
