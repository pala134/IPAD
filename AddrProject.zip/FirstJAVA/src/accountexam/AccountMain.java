package accountexam;

import java.util.Scanner;

public class AccountMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Account account = new Account();
		System.out.println("계좌정보를 입력하세요");
		System.out.print("계좌명의 : ");
		account.name = scanner.nextLine();
		System.out.print("계좌번호 : ");
		account.no = scanner.nextInt();
		System.out.print("잔고 : ");
		account.balance = scanner.nextInt();
		System.out.printf("계좌 기본 정보 : {%s, %d, %d}\n", account.name, account.no, account.balance);
		System.out.print("출금액 : ");
		account.deposit = scanner.nextInt();
		System.out.printf("잔금은 %d 입니다", account.deposit());
		
		scanner.close();
	}

}
