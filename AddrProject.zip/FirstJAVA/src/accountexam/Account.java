package accountexam;

public class Account {
	String name;
	int no;
	int balance;
	int deposit;
	Account (){}
	Account(String name, int no, int balance){
		this.name = name;
		this.no = no;
		this.balance = balance;
	}
	
	String getName() {
		return name;}
	int getNo() {
		return no;}
	int getBalance() {
		return balance;}
	int deposit() {
		balance -= deposit;
		return balance;
	}
	
	
}
