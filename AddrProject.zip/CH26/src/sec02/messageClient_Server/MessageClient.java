package sec02.messageClient_Server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class MessageClient {

	public static void main(String[] args) throws Exception {
		Socket s = new Socket("172.30.1.79", 8888);
		
		DataInputStream din = new DataInputStream(s.getInputStream());
		DataOutputStream dout = new DataOutputStream(s.getOutputStream());
		Scanner sc = new Scanner(System.in);
		
		String str = "", str2="";
		
		while(!str.equals("exit")){
			str = sc.nextLine();
			dout.writeUTF(str);
			dout.flush();
			str2 = din.readUTF();
			System.out.println("Server Message: "+str2);
			
		}
		dout.close();
		s.close();
	}

}
