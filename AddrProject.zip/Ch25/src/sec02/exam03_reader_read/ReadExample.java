package sec02.exam03_reader_read;

import java.io.FileReader;
import java.io.Reader;
import java.net.InetAddress;

public class ReadExample {

	public static void main(String[] args) throws Exception {
		Reader reader = new FileReader("C:/Temp/test.txt");
		
		int i = 0;
		while (true) {
			i++;
			int readData = reader.read();
			if(readData==-1)break;
			
			System.out.println(readData);
			System.out.println((char)readData);
			
		}
		System.out.println("i : "+(i-1));
		
		reader.close();
		String ip = InetAddress.getLocalHost().getHostAddress();
		System.out.println(ip);
	}

}
