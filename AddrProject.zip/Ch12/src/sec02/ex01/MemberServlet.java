package sec02.ex01;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class MemberServlet
 */
@WebServlet("/member")
public class MemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public MemberServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("doGet");
		actionDo(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("doPost");
		actionDo(request, response);
	}

	private void actionDo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
	    PrintWriter out=response.getWriter();
		String mname = request.getParameter("name");
		MemberVO memberVO = new MemberVO();
		memberVO.setName(mname);
		MemberDAO dao = new MemberDAO();
		List membersList = dao.listMembers(memberVO);
		
		out.print("<html><body>");
		out.print("<table border='1' width='800' align='center'>");
		out.print("<tr align='center' bgcolor='red'>");
		out.print("<td>아이디</td><td>비밀번호</td><td>이름</td><td>이메일</td><td>가입일자</td><tr>");
		
		for (int i = 0; i < membersList.size(); i++) {
			MemberVO vo = (MemberVO) membersList.get(i);
			String id = vo.getId();
			String pwd = vo.getPwd();
			String name = vo.getName();
			String email = vo.getEmail();
			Date joinDate = vo.getJoinDate();
			
			out.print("<tr align=center><td>"+id+"</td><td>"
		                +pwd+"</td><td>"
		                +name+"</td><td>"
		                +email+"</td><td>"
		                +joinDate+"</td></tr>");
		}
		out.print("</table></body></html>");
		out.print("<a href='/Ch12/test03/search.jsp'>재검색 하기</a>");
	}

}
