package com.ipad.dto.saleAnalysis;

public class PatientDto {
	private String adm_cd;
	private String region_name;
	private int patient;
	private int sale;
	private float employee;
	private float areasize;
	                                                                 
	public String getAdm_cd() {
		return adm_cd;
	}
	public void setAdm_cd(String adm_cd) {
		this.adm_cd = adm_cd;
	}
	public String getRegion_name() {
		return region_name;
	}
	public void setRegion_name(String region_name) {
		this.region_name = region_name;
	}
	public int getPatient() {
		return patient;
	}
	public void setPatient(int patient) {
		this.patient = patient;
	}
	public int getSale() {
		return sale;
	}
	public void setSale(int sale) {
		this.sale = sale;
	}
	public float getEmployee() {
		return employee;
	}
	public void setEmployee(float employee) {
		this.employee = employee;
	}
	public float getAreasize() {
		return areasize;
	}
	public void setAreasize(float areasize) {
		this.areasize = areasize;
	}
	
	
}
