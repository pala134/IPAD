package com.Ex9_2;

public class TreeNode {
	char data;
	TreeNode left;
	TreeNode right;
}


