package com.Ex9_1;

public class TreeNode {
	Object data;
	TreeNode left;
	TreeNode right;
}
