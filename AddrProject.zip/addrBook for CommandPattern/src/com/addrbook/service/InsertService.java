package com.addrbook.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface InsertService {
	public void execute(HttpServletRequest request, HttpServletResponse response);
}
